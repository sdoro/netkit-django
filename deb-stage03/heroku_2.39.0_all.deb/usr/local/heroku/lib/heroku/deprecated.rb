require "heroku"

module Heroku::Deprecated
end

