module Heroku
  VERSION = "2.39.0"
end
